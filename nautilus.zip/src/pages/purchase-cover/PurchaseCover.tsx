import React from "react";

export default function PurchaseCover() {
  return <div>PurchaseCover</div>;
}
