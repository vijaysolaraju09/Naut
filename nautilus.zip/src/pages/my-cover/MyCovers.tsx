import React from "react";

export default function MyCovers() {
  return <div>MyCover</div>;
}
