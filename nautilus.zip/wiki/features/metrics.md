## SonarCloud Report 
<br/><img src="https://github.com/NeoSOFT-Technologies/frontend-reactjs/blob/main/wiki/images/SonarCloud.png"/>

## Unit TestCases Report
<br/><img src="https://github.com/NeoSOFT-Technologies/frontend-reactjs/blob/main/wiki/images/Unit_testcases.png"/>

## E2E TestCases Report
<br/><img src="https://github.com/NeoSOFT-Technologies/frontend-reactjs/blob/main/wiki/images/E2E_testing.png"/>