## Branch Naming Conventions  
<br/><img src="https://github.com/NeoSOFT-Technologies/frontend-reactjs/blob/main/wiki/images/Git_Branching_Convention.png"/>

