import React from "react";

export default function Pagination() {
  return (
    <div className="d-flex align-items-center gap-3">
      <button className="btn btn-light" disabled>
        previous
      </button>
      <button className="btn btn-light bg-success">1</button>
      <button className="btn btn-light">2</button>
      <button className="btn btn-light">3</button>
      <button className="btn btn-light">next</button>
    </div>
  );
}
